/* $Id$ */
/* Snort Detection Plugin Header File Template */

/* 
 * This file gets included in plugbase.h when it is integrated into the rest 
 * of the program.  
 *
 * Export any functions or data structs you feel necessary.
 */

#ifndef __SP_TEMPLATE_H__
#define __SP_TEMPLATE_H__

void SetupTemplate();

#endif  /* __SP_TEMPLATE_H__ */
